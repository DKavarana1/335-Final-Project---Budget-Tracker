Submitted by: Darius Kavarana (directory id: dkavaran)

Group Members: Darius Kavarana (dkavaran), Calvin Hughes(chughes0), and Sohan Chokshi (schoksh2)

App Description: Our application is a personal budget tracker. We used node.js and mongodb within the application. The way ou application works is by having the user type in the values, currency used, and then save it to their profile (aka their name). From there by searching their name they can see where their money is being spent and which category (all converted to USD).

YouTube Video Link: https://youtu.be/syAB0i77bZE?si=tib0kHaWcFX6kKxR

APIs: CurrencyAPI (https://currencyapi.com). Documentation for this API (https://currencyapi.com/docs)

Contact Email: schoksh2@terpmail.umd.edu

Render Link: https://three35-final-project-budget-tracker-gk2l.onrender.com
